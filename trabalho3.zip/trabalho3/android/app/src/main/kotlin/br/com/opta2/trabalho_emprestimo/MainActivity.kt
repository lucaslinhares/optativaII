package br.com.opta2.trabalho_emprestimo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
